$(document).ready(function(){
    $("#circle-twelve").click(function(){
        $("#animated-image img.top").toggleClass("transparent");
    });
    $("#circle-twelve").dblclick(function(){
        $("#soundtrack10v2")[0].pause();
    });
});
